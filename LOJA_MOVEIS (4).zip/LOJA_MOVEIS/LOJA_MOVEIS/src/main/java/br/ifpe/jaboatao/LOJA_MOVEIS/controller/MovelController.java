package br.ifpe.jaboatao.LOJA_MOVEIS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import br.ifpe.jaboatao.LOJA_MOVEIS.model.Movel;
import br.ifpe.jaboatao.LOJA_MOVEIS.service.MovelService;

@Controller
@RequestMapping("/moveis")
public class MovelController {

    @Autowired
    private MovelService movelService;

    // Exibir lista de móveis
    @GetMapping
    public String listaMoveis(Model model) {
        model.addAttribute("moveis", movelService.listarMoveis());
        return "moveis";
    }

    // Exibir formulário de cadastro
    @GetMapping("/cadastro")
    public String cadastro() {
        return "cadastro";
    }

    // Cadastro de novo móvel
    @PostMapping("/cadastro")
    public String cadastrarMovel(Movel movel) {
        movelService.salvarMovel(movel);
        return "redirect:/moveis";
    }

    // Editar móvel
    @GetMapping("/update/{id}")
    public String editarMovel(@PathVariable Long id, Model model) {
        Movel movel = movelService.buscarPorId(id);
        model.addAttribute("movel", movel);
        return "update";
    }

    // Atualizar móvel
    @PostMapping("/update/{id}")
    public String atualizarMovel(@PathVariable Long id, Movel movel) {
        movel.setId(id);
        movelService.atualizarMovel(movel);
        return "redirect:/moveis";
    }

    // Deletar móvel
    @GetMapping("/delete/{id}")
    public String deletarMovel(@PathVariable Long id) {
        movelService.deletarMovel(id);
        return "redirect:/moveis";
    }
}
