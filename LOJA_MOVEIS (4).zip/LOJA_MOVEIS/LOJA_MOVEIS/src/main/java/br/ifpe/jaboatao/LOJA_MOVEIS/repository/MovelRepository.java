package br.ifpe.jaboatao.LOJA_MOVEIS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import br.ifpe.jaboatao.LOJA_MOVEIS.model.Movel;

// O JpaRepository fornece métodos para manipulação do banco
public interface MovelRepository extends JpaRepository<Movel, Long> {
    // Métodos adicionais de consulta podem ser adicionados aqui, se necessário
}
