package br.ifpe.jaboatao.LOJA_MOVEIS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import br.ifpe.jaboatao.LOJA_MOVEIS.service.MovelService;

@Controller
public class HomeController {

    @Autowired
    private MovelService movelService;

    @GetMapping("/")
    public String home() {
        return "home";  // Retorna o template home.html
    }

    @GetMapping("/moveis")
    public String listaMoveis(Model model) {
        model.addAttribute("moveis", movelService.listarMoveis());  // Lista os móveis no modelo
        return "moveis";  // Retorna o template moveis.html
    }

    @GetMapping("/moveis/cadastro")
    public String cadastroMovel() {
        return "cadastro";  // Retorna o template cadastro.html
    }
}
