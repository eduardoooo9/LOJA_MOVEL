package br.ifpe.jaboatao.LOJA_MOVEIS.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "estante")
public class Estante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String modelo;
    private double preco;

    // Getter para o 'id'
    public Long getId() {
        return id;
    }

    // Setter para o 'id'
    public void setId(Long id) {
        this.id = id;
    }

    // Getter para o 'modelo'
    public String getModelo() {
        return modelo;
    }

    // Setter para o 'modelo'
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    // Getter para o 'preco'
    public double getPreco() {
        return preco;
    }

    // Setter para o 'preco'
    public void setPreco(double preco) {
        this.preco = preco;
    }
}
